# MERN-ECOMMERCE_WEBSITE
An e-commerce store with 2 payment gateway integration, by using mongo, Express, React and Nodejs.
